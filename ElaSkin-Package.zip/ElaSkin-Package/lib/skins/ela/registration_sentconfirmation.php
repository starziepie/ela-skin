<div class="unix-login">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-4">
                <div class="login-content card">
                    <div class="login-form">
                        <h4><i class="icon fa fa-check"></i> Confirmation Sent</h4>
                        Thanks for registering for <?php echo SITE_NAME; ?>. You will be notified via email of your registration status.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>