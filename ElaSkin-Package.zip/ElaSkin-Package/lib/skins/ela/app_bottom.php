<?php if(!defined('IN_PHPVMS') && IN_PHPVMS !== true) { die(); } ?>
                <!-- Footer -->
                <footer class="footer" style="margin: 0;">
                    <div class="pull-right">
                        CrewCenter by <a href="https://instagram.com/carlosmeduardo" data-toggle="tooltip" title="Designed by Carlos Eduardo" target="_blank">ElixarCode</a> | Powered by phpVMS
                    </div>
                    <strong>Copyright &copy; <?php echo date('Y') ?> <?php echo SITE_NAME; ?></strong>
                </footer>
                <!-- End footer -->
            </div>
            <!-- End Page wrapper  -->
        </div>
        <!-- End Wrapper -->